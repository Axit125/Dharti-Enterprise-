import 'package:flutter/material.dart';
import 'package:axit_s_application1/presentation/welcome_screen/welcome_screen.dart';
import 'package:axit_s_application1/presentation/login_screen/login_screen.dart';
import 'package:axit_s_application1/presentation/sign_up_screen/sign_up_screen.dart';
import 'package:axit_s_application1/presentation/home_container_screen/home_container_screen.dart';
import 'package:axit_s_application1/presentation/blender_screen/blender_screen.dart';
import 'package:axit_s_application1/presentation/checkout_screen/checkout_screen.dart';
import 'package:axit_s_application1/presentation/confirm_orders_screen/confirm_orders_screen.dart';
import 'package:axit_s_application1/presentation/address_screen/address_screen.dart';
import 'package:axit_s_application1/presentation/my_orders_screen/my_orders_screen.dart';
import 'package:axit_s_application1/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String welcomeScreen = '/welcome_screen';

  static const String loginScreen = '/login_screen';

  static const String signUpScreen = '/sign_up_screen';

  static const String homePage = '/home_page';

  static const String homeContainerScreen = '/home_container_screen';

  static const String categoriesPage = '/categories_page';

  static const String blenderScreen = '/blender_screen';

  static const String myBagPage = '/my_bag_page';

  static const String checkoutScreen = '/checkout_screen';

  static const String confirmOrdersScreen = '/confirm_orders_screen';

  static const String addressScreen = '/address_screen';

  static const String favoritesPage = '/favorites_page';

  static const String myProfilePage = '/my_profile_page';

  static const String myOrdersScreen = '/my_orders_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    welcomeScreen: (context) => WelcomeScreen(),
    loginScreen: (context) => LoginScreen(),
    signUpScreen: (context) => SignUpScreen(),
    homeContainerScreen: (context) => HomeContainerScreen(),
    blenderScreen: (context) => BlenderScreen(),
    checkoutScreen: (context) => CheckoutScreen(),
    confirmOrdersScreen: (context) => ConfirmOrdersScreen(),
    addressScreen: (context) => AddressScreen(),
    myOrdersScreen: (context) => MyOrdersScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
