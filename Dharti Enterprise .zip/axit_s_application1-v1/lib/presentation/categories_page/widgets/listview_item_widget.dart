import 'package:axit_s_application1/core/app_export.dart';
import 'package:axit_s_application1/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListviewItemWidget extends StatelessWidget {
  ListviewItemWidget({
    Key? key,
    this.onTapButtonText,
  }) : super(
          key: key,
        );

  VoidCallback? onTapButtonText;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220.v,
      width: 356.h,
      child: Stack(
        alignment: Alignment.centerRight,
        children: [
          Align(
            alignment: Alignment.center,
            child: Container(
              margin: EdgeInsets.only(right: 1.h),
              padding: EdgeInsets.symmetric(vertical: 66.v),
              decoration: AppDecoration.fillOnPrimary,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 7.v),
                  Container(
                    height: 81.v,
                    width: 150.h,
                    decoration: BoxDecoration(
                      color: appTheme.whiteA700,
                    ),
                  ),
                ],
              ),
            ),
          ),
          CustomElevatedButton(
            height: 124.v,
            width: 150.h,
            text: "Blender",
            buttonStyle: CustomButtonStyles.fillWhiteA,
            buttonTextStyle: theme.textTheme.headlineSmall!,
            onTap: () {
              onTapButtonText?.call();
            },
            alignment: Alignment.centerRight,
          ),
        ],
      ),
    );
  }
}
