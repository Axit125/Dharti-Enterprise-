// ignore_for_file: must_be_immutable

import 'package:axit_s_application1/core/app_export.dart';
import 'package:axit_s_application1/widgets/custom_elevated_button.dart';
import 'package:axit_s_application1/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);

  TextEditingController userNameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(horizontal: 37.h, vertical: 38.v),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 3.h, top: 47.v),
                  child:
                      Text("Login Now", style: theme.textTheme.headlineLarge),
                ),
                Container(
                  width: 243.h,
                  margin: EdgeInsets.only(left: 3.h, right: 73.h),
                  child: Text(
                    "Please login or sign up to continue using\nour app",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: CustomTextStyles.labelLargeMplus1pBoldBold,
                  ),
                ),
                SizedBox(height: 21.v),
                CustomTextFormField(
                  controller: userNameController,
                  margin: EdgeInsets.only(top: 24.v, right: 11.h),
                  hintText: "Username",
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Username is required';
                    }
                    // Add additional username validation logic here if needed
                    return null;
                  },
                ),
                CustomTextFormField(
                  controller: passwordController,
                  margin: EdgeInsets.only(top: 22.v, right: 11.h),
                  hintText: "Password",
                  textInputAction: TextInputAction.done,
                  textInputType: TextInputType.visiblePassword,
                  suffix: Container(
                    margin: EdgeInsets.fromLTRB(30.h, 15.v, 12.h, 14.v),
                    child: CustomImageView(svgPath: ImageConstant.imgMdieye),
                  ),
                  suffixConstraints: BoxConstraints(maxHeight: 53.v),
                  obscureText: true,
                  contentPadding: EdgeInsets.only(
                    left: 30.h,
                    top: 11.v,
                    bottom: 11.v,
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Password is required';
                    }
                    // Add additional password validation logic here if needed
                    return null;
                  },
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: EdgeInsets.only(top: 21.v, right: 15.h),
                    child: Text("Forgot Password?",
                        style: CustomTextStyles.labelLargeMplus1pBold),
                  ),
                ),
                CustomElevatedButton(
                  text: "Login",
                  margin: EdgeInsets.only(left: 3.h, top: 52.v, right: 6.h),
                  onTap: () {
                    if (_formKey.currentState!.validate()) {
                      // If the form is valid, perform your action.
                      onTapLogin(context);
                    }
                  },
                ),
                Align(
                  alignment: Alignment.center,
                  child: Padding(
                    padding:
                        EdgeInsets.only(left: 37.h, top: 20.v, right: 23.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(bottom: 7.v),
                          child: Text("Don’t have an account?  ",
                              style: CustomTextStyles.labelLargeMplus1pBold),
                        ),
                        CustomElevatedButton(
                          height: 27.v,
                          width: 100.h,
                          text: "Sign up",
                          margin: EdgeInsets.only(left: 7.h),
                          buttonStyle: CustomButtonStyles.fillBlueGray,
                          buttonTextStyle:
                              CustomTextStyles.labelLargeMplus1pBoldPrimary,
                          onTap: () {
                            onTapSignup1(context);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void onTapLogin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.homeContainerScreen);
  }

  void onTapSignup1(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signUpScreen);
  }
}
